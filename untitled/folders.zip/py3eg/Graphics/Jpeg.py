#!/usr/bin/env python3


def load(filename):
    print("jpeg: load", filename)


def save(filename):
    print("jpeg: save", filename)


def width():
    print("jpeg: width")


def height():
    print("jpeg: height")


def color_at(x, y):
    print("jpeg: color_at")


def set_color_at(x, y, color):
    print("jpeg: set_color_at")
