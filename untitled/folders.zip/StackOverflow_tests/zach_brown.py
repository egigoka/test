import io, sys

one = open(sys.argv[1]).readlines()
two = open(sys.argv[2]).readlines()

for n in [1,3,5,7,9,11,17,19,21,23]:
    one[n] = one[n][:-1]+"|"+two[n].partition("|")[2]

open(sys.argv[3],"w").write("".join(one))