# test
I'm just learning Python. You can help, if you want. Some code in Russian.
