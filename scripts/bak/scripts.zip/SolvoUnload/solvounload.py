﻿#! python3
import sys
import os
import win_unicode_console
import subprocess
import time
import colorama
from utils import *

# init
#win_unicode_console.enable()
#colorama.init()
scriptsFolder = r"\\192.168.99.91\shares\scripts"
scriptsSubFolderName = "SolvoUnload"
scriptsSubFolder = scriptsFolder + "\ "[:1] + scriptsSubFolderName  # "\\192.168.99.91\shares\scripts\SolvoUnload"
settingsJsonName = "settings.json"
settingsJsonFile = scriptsSubFolder + "\ "[:1] + settingsJsonName
# "\\192.168.99.91\shares\scripts\SolvoUnload\settings.json"
createdirs(scriptsFolder)
createdirs(scriptsSubFolder)
createfile(settingsJsonFile)
jsonStringInMemory = loadjson(settingsJsonFile)
savejson(settingsJsonFile, jsonStringInMemory)


debugprint = 0
if debugprint == True:
    print("settingsJsonFile:")
    print(settingsJsonFile)
    print("jsonStringInMemory:")
    print(jsonStringInMemory)


if __name__ == '__main__':
    def main():
        print("Введите кол-во накладных или выберите пункт меню:")
        print("[b] - Изменить последнее время отгруженных рейсов", jsonStringInMemory["last_batch"])
        print("[o] - Изменить последнее время отгруженных непривязанных накладных", jsonStringInMemory["last_onebyone"])
        print("[s] - Изменить скорость отгрузки накладных", jsonStringInMemory["nakl_per_sec"])
        print("[d] - Debug")
        inputMenuItem = input("Введите что-нибудь: ")
        if "b" in inputMenuItem:
            jsonStringInMemory["last_batch"] = input("Новое последнее время отгруженных рейсов: ")
            savejson(settingsJsonFile, jsonStringInMemory)
        elif "o" in inputMenuItem:
            jsonStringInMemory["last_onebyone"] = input("Новое последнее время отгруженных непривязанных накладных: ")
            savejson(settingsJsonFile, jsonStringInMemory)
        elif "s" in inputMenuItem:
            try:
                jsonStringInMemory["nakl_per_sec"] = float(input("Новая скорость отгрузки накладных: "))
                savejson(settingsJsonFile, jsonStringInMemory)
                main()
            except ValueError:
                print("Это не число")
                main()
        elif "d" in inputMenuItem:
            subprocess.call([notepadExec, settingsJsonFile])
            main()
        elif "e" in inputMenuItem:
            sys.exit()
        else:
            try:
                #count = int(float(inputMenuItem) * jsonStringInMemory["nakl_per_sec"])
                inputMenuItem = int(inputMenuItem)
                inputMenuItem -= 15
                inputMenuItem = float(inputMenuItem)
                count = 15 + (inputMenuItem / 15 * 10)
                count = int(count)
                while count > 0:
                    try:
                        mins = str(int(count/60))
                        secs = str(int(count%60))
                        print(mins + "m" + secs + "s,")
                        time.sleep(1)
                        count += -1
                    except KeyboardInterrupt as err:
                        main()
                screenblink(width = 82, height = 25)
                # todo sound or color
            except ValueError as err:
                print(err)
                print("Вообще ничего не понял, давай сначала")
            except NameError as err:
                print (err)
    while True:
        main()
    # todo open bartender



