#! python3
import sys
import os
import win_unicode_console
import subprocess
import time
from utils import *

# init
ifDebug = True
win_unicode_console.enable()
scriptsFolder = r"\\192.168.99.91\shares\scripts"
scriptsSubFolderName = "BartenderPrint"
scriptsSubFolder = scriptsFolder + "\ "[:1] + scriptsSubFolderName  # "\\192.168.99.91\shares\scripts\BartenderPrint"
bartenderDocumentsFolder = r"\\192.168.99.91\shares\scripts\BartenderPrint\Bartender Documents"
bartenderMineDockumentsSubFolder = bartenderDocumentsFolder + "\ "[:1] + "Егоров"
bartenderFolder = "C:\Program Files (x86)\Seagull\Bartender Suite"
bartenderExecName = "bartend.exe"
bartenderExec = bartenderFolder + "\ "[:1] + bartenderExecName
# "C:\Program Files (x86)\Seagull\Bartender Suite\bartend.exe"
notepadExecName = "notepad++.exe"
notepadFolder = r"C:\Program Files (x86)\Notepad++"
notepadExec = pathInWindowsExtend(notepadFolder, notepadExecName)
settingsJsonName = "settings.json"
settingsJsonFile = scriptsSubFolder + "\ "[:1] + settingsJsonName
# "\\192.168.99.91\shares\scripts\BartenderPrint\settings.json"
outputFileName = "Бирки_output.txt"
outputFile = bartenderDocumentsFolder + "\ "[:1] + outputFileName
# "C:\Users\Sklad_solvo\Documents\BarTender\BarTender Documents\Бирки_output.txt"
createdirs(scriptsFolder)
createdirs(scriptsSubFolder)
createfile(settingsJsonFile)
if ifDebug == True:
    filebackup(settingsJsonFile)
    filebackup(pathInWindowsExtend(scriptsSubFolder, "bartendernogui.py"))
    print("settingsJsonFile:", end = "")
    print(settingsJsonFile)
jsonStringInMemory = loadjson(settingsJsonFile)
savejson(settingsJsonFile, jsonStringInMemory)





def bartenderDocument(name):
    path = str(bartenderDocumentsFolder) + "\ "[:1] + str(name) + ".btw"
    return path


def bartenderMineDocument(name):
    path = str(bartenderMineDockumentsSubFolder) + "\ "[:1] + str(name) + ".btw"
    return path


def newPrintBars(cntBars, groupName, filesavename = outputFile):
    jsonStringInMemory = loadjson(settingsJsonFile)
    prefix = jsonStringInMemory[groupName]["prefix"]
    startCnt = jsonStringInMemory[groupName]["lastnum"]
    cnt = startCnt + 1
    file = open(filesavename, 'w')
    endCnt = startCnt + cntBars
    jsonStringInMemory[groupName]["lastnum"] = endCnt
    savejson(settingsJsonFile, jsonStringInMemory)
    while cnt <= endCnt:
        file.write(str(prefix) + str(cnt) + '\n')
        print(str(prefix) + str(cnt))
        cnt += 1
    file.close()


def runBartender(database=outputFile, type="kompl",size="58*60"):
    database = None
    # todo разные файлы для разного количества символов
    # todo isprint check from json
    time.sleep(1)
    if type == "kompl" and size == "58*60":
        bartenderFile = bartenderMineDocument("Бирки 58x60")
        subprocess.call([bartenderExec, bartenderFile, "/P", "/X"])
    if type == "cell" and size == "58*60":
        bartenderFile = bartenderMineDocument("Бирки 58x60 9 симв")
        subprocess.call([bartenderExec, bartenderFile, "/P", "/X"])



if __name__ == '__main__':
    def main():#todo печать просто текста и повторяющегося текста
        taskkill("bartend")
        print("Выберите группу:")
        print("[1] - 1 группа")
        print("[2] - 2 группа")
        print("[3] - 3 группа")
        print("[4] - 4 группа")
        print("[5] - 5 группа")
        print("[6] - Грузы")
        print("[7] - Форпост")
        print("[8] - Алкоголь")
        print("[10]- 10 группа")
        print("[t] - 1 ячейку")
        print("[mt]- Несколько ячеек")
        print("[gp]- Грузчики логин (не сделано)")#todo сделать
        print("[e] - Выход")
        print("[dk]- Debug kompl")
        print("[dc]- Debug cell")
        print("[kill] - kill bartender processes")
        print("[new] -- new cmd window")
        inputGroupAndCount = input("Введите номер: ")
        if "10" in inputGroupAndCount:
            groupname = "group10"
        elif "1" in inputGroupAndCount:
            groupname = "group1"
        elif "2" in inputGroupAndCount:
            groupname = "group2"
        elif "3" in inputGroupAndCount:
            groupname = "group3"
        elif "4" in inputGroupAndCount:
            groupname = "group4"
        elif "5" in inputGroupAndCount:
            groupname = "group5"
        elif "6" in inputGroupAndCount:
            groupname = "shipments"
        elif "7" in inputGroupAndCount:
            groupname = "group_forp"
        elif "8" in inputGroupAndCount:
            groupname = "group_alco"
        elif "mt"  in inputGroupAndCount:
            wipefile(outputFile)
            subprocess.call([notepadExec, outputFile])
            runBartender(type="cell")
            main()
        elif "t" in inputGroupAndCount:
            text = input("Text:")
            file = open(outputFile, 'w')
            file.write(text)
            file.close()
            runBartender(type="cell")
            main()
        elif ("e" in inputGroupAndCount) or ("у" in inputGroupAndCount):
            sys.exit()
        elif "dk" in inputGroupAndCount:
            bartenderFile = bartenderMineDocument("Бирки 58x60")
            barsCnt = int(input("Сколько нужно бирок каждой группы?"))
            groupnames = ["group1", "group2", "group3", "group4", "group5", "shipments", "group_forp", "group_alco", "group10", ]
            if barsCnt != 0:
                for group in groupnames:
                    newPrintBars(barsCnt, group)
                    runBartender()
            subprocess.call([bartenderExec, bartenderFile])
            subprocess.call([notepadExec, settingsJsonFile])
            subprocess.call([notepadExec, outputFile])
            main()
        elif "dc" in inputGroupAndCount:
            bartenderFile = bartenderMineDocument("Бирки 58x60 9 симв")
            subprocess.call([bartenderExec, bartenderFile])
            subprocess.call([notepadExec, outputFile])
            main()
        elif "gp" in inputGroupAndCount:
            print("ГРУЗЧИКИ НАДО СДЕЛАТЬ")
            #todo грузчики btd txt txt
            main()
        elif "kill" in inputGroupAndCount:
            print("Killing bartend*")
            os.system("taskkill /f /im bartend*")
            main()
        elif "new" in inputGroupAndCount:
            try:
                os.system("start cmd")
            except:
                print("Kan knot :D")
                main()
            main()
        else:
            print("error")
            print(inputGroupAndCount)
            main()
        try:
            newPrintBars(int(input("Сколько нужно бирок?")), groupname)
            runBartender()
            main()
        except ValueError as err:
            print(err)
            main()
        main()
    while True:
        main()
    # todo open bartender



