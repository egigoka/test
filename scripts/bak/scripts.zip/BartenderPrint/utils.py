#! python3
# version 1.0.3
# init ver
# f createdirs
# f createfile
# f savejson
# f loadjson
# f pathInWindowsWithSpacesToQuotes
# f pathInWindowsExtend
# ver 1.0.1
# f taskkill
# f jsonload print "json loaded" output
# f jsonsave print "json saved" output
# ver 1.0.2
# f wipefile
# ver 1.0.3
# f jsonbackup
# f jsonrestorebak todo
# f jsoncheck todo
# f timestamp
import os, \
       json, \
       sys, \
       shutil, \
       time


def createdirs(filename):
    dir = os.path.dirname(filename)
    if not os.path.exists(dir):
        os.makedirs(dir)


def createfile(filename):
    dir = os.path.dirname(filename)
    if not os.path.exists(dir):
        os.makedirs(dir)
    if not os.path.exists(filename):
        open(filename, 'a').close()


def timestamp():
    ts = time.time()
    return ts


def filebackup(filename):
    backupfilename = str(filename) + "." + str(timestamp()) + ".bak"
    shutil.copy2(filename, backupfilename)
    print("backup of file", filename, "created as", backupfilename)


def jsoncheck(filename):
    try:
        loadjson(filename)
    except:
        print("JSON is bad")


def savejson(filename, jsonstring):
    try:
        settingsJsonTextIO = open(filename, "w")
        json.dump(jsonstring, settingsJsonTextIO)
        settingsJsonTextIO.close()
        print("JSON format succesfull saved")
    except:
        print("Error while saving JSON")


def loadjson(filename):
    try:
        settingsJsonTextIO = open(filename)
        jsonStringInMemory = json.load(settingsJsonTextIO)
        settingsJsonTextIO.close()
        print("JSON format succesfull loaded")
        return jsonStringInMemory
    except:
        print("Error while loading JSON")
        print("Try to repair JSON")
        print("Script is closing")
        sys.exit()


def pathInWindowsWithSpacesToQuotes(path):
    path = '"' + str(path) + '"'
    return path

def pathInWindowsExtend(path_1st, path_2nd):
    path = str(path_1st) + "\ "[:1] + str(path_2nd)
    return path

def taskkill(process):
    command_ = "taskkill /f /im " + str(process) + ".exe"
    os.system(command_)
    return command_


def wipefile(path):
    file = open(path, 'w')
    file.close()


