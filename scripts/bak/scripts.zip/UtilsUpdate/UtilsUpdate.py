#! python3
from utils_dev import *
import os
import sys
#init
scriptsFolder = r"\\192.168.99.91\shares\scripts"
scriptsSubFolderName = "UtilsUpdate"
utils_devName = "utils_dev.py"
utils_devPath = pathInWindowsExtend(scriptsFolder, scriptsSubFolderName, utils_devName)

def check_version(utils_py_file):
    file = open(utils_py_file)
    for string in file:
        if string[0:10] == "# version ":
            version = string[10:]
            isDevVersion = False
            if "d" in version:
               isDevVersion = True
            if "\n" in version:
                pos = version.rfind("\n")
                version = version[:pos]
            break
    return version, isDevVersion


def check_update(name, path):
    newest_version = check_version(utils_devPath)
    checking_version = check_version(path)
    print("Found version " + str(checking_version) + " in " + str(name) + ", actual is " + str(newest_version))
    #if (isDevVersion == False) & () todo bigger version
    # todo WARNING UPPER VERSION
    #return

paths = {}
paths["SolvoUnload"] = r"\\192.168.99.91\shares\scripts\SolvoUnload\utils.py"
paths["BartenderPrint"] = r"\\192.168.99.91\shares\scripts\BartenderPrint\utils.py"

for name in paths:
    path = paths[name]
    check_update(name, path)
#update_utils(path)

#def check_update_old(path, name = "Unknown"):
#    newest_version = check_version(utils_devPath)
#    checking_version = check_version(path)
#    print("Found version " + str(checking_version) + " in " + str(name) + ", actual is " + str(newest_version))
#    #if (isDevVersion = False) & ()
#    # todo WARNING UPPER VERSION
#    return
#
#paths = [r"\\192.168.99.91\shares\scripts\SolvoUnload\utils.py"]
#paths += [r"\\192.168.99.91\shares\scripts\BartenderPrint\utils.py"]
#print(paths)
#for path in paths:
#    check_update(path)