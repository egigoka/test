#! python3
# version 1.0.8
# init ver
# f createdirs
# f createfile
# f savejson
# f loadjson
# f pathInWindowsWithSpacesToQuotes
# f pathInWindowsExtend
# ver 1.0.1
# f taskkill
# f jsonload print "json loaded" output
# f jsonsave print "json saved" output
# ver 1.0.2
# f wipefile
# ver 1.0.3
# f jsonbackup
# f jsonrestorebak todo
# f jsoncheck todo
# f timestamp
# ver 1.0.4
# f screenblink
# ver 1.0.5
# update pathInWindowsExtend - three path extend now
# ver 1.0.6
# update pathInWindowsExtend - unlimited args now#
# ver 1.0.7
# update pathInWindowsExtend - bugfix
# ver 1.0.8
# update pathInWindowsExtend - bugfix
import os, \
       json, \
       sys, \
       shutil, \
       time, \
       termcolor, \
       colorama, \
       random, \
       win_unicode_console
#win_unicode_console.enable()
colorama.init()
colorama.deinit()


def createdirs(filename):
    dir = os.path.dirname(filename)
    if not os.path.exists(dir):
        os.makedirs(dir)


def createfile(filename):
    dir = os.path.dirname(filename)
    if not os.path.exists(dir):
        os.makedirs(dir)
    if not os.path.exists(filename):
        open(filename, 'a').close()


def timestamp():
    ts = time.time()
    return ts


def filebackup(filename):
    backupfilename = str(filename) + "." + str(timestamp()) + ".bak"
    shutil.copy2(filename, backupfilename)
    print("backup of file", filename, "created as", backupfilename)


def jsoncheck(filename):
    try:
        loadjson(filename)
    except:
        print("JSON is bad")


def savejson(filename, jsonstring):
    try:
        settingsJsonTextIO = open(filename, "w")
        json.dump(jsonstring, settingsJsonTextIO)
        settingsJsonTextIO.close()
        print("JSON format succesfull saved")
    except:
        print("Error while saving JSON")


def loadjson(filename):
    try:
        settingsJsonTextIO = open(filename)
        jsonStringInMemory = json.load(settingsJsonTextIO)
        settingsJsonTextIO.close()
        print("JSON format succesfull loaded")
        return jsonStringInMemory
    except:
        print("Error while loading JSON")
        print("Try to repair JSON")
        print("Script is closing")
        sys.exit()


def pathInWindowsWithSpacesToQuotes(path):
    path = '"' + str(path) + '"'
    return path

def pathInWindowsExtend(*paths):
    for path_ in paths:
        try:
            path
            path = str(path) + "\ "[:1] + str(path_)
        except:
            path = path_
    return path

def taskkill(process):
    command_ = "taskkill /f /im " + str(process) + ".exe"
    os.system(command_)
    return command_


def wipefile(path):
    file = open(path, 'w')
    file.close()


def screenblink(width = 80, height = 40, symbol = "#", sleep = 0.1):
    try:
        colorama.reinit()
        while True:
            colors = ["grey", "red", "green", "yellow", "blue", "magenta", "cyan", "white"]
            highlights = ["on_grey", "on_red", "on_green", "on_yellow", "on_blue", "on_magenta", "on_cyan", "on_white"]
            string = symbol * width
            color = random.choice(colors)
            colors.pop(colors.index(color))
            highlight = random.choice(highlights)
            #print (termcolor.colored(color + on + highlight,color,highlight))
            try:
                height_ = height
                while height_ > 0:
                #print string
                    print(termcolor.colored(string, color, highlight))
                    height_ -= 1
                time.sleep(sleep)
            except KeyboardInterrupt as err:
                print ("OK")
                colorama.deinit()
                break
    except:
        print("Except1")

if __name__ == "__main__":
    screenblink()